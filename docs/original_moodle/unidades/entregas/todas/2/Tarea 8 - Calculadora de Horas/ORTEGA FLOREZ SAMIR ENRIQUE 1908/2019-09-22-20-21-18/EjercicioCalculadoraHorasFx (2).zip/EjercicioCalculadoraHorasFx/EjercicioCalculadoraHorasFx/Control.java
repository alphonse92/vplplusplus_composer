import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.StageStyle;
import javafx.scene.control.CheckBox;
public class Control {

    @FXML
    private Button cmdGuardarDatos;

    @FXML
    private Button cmdLimpiarDatos;

    @FXML
    private Button cmdComparar;

    @FXML
    private Button cmdRestarHora;

    @FXML
    private Button cmdCambiarF;

    @FXML
    private Button cmdAyuda;

    @FXML
    private TextField txtHora1;

    @FXML
    private TextField txtMinuto1;

    @FXML
    private TextField txtSegundo1;

    @FXML
    private TextField txtHora2;

    @FXML
    private TextField txtMinuto2;

    @FXML
    private TextField txtSegundo2;
    
     @FXML
    private CheckBox chexboxHora112;

    @FXML
    private CheckBox chexboxHora124;

    @FXML
    private CheckBox chexboxHora212;

    @FXML
    private CheckBox chexboxHora224;

    @FXML
    private TextField txtResta;

    @FXML
    private TextField txtHorasComparadas;

    @FXML
    private TextField txtFormato;

    
    private Hora hora;
    private Hora hora1;
    public Control(){
        hora = new Hora();
        hora1 = new Hora();
    }
    

    @FXML
    public void ayuda() {
        Alert alert = new Alert(AlertType.INFORMATION);
       alert.initStyle(StageStyle.UTILITY);
       alert.setTitle("Ayuda");
       alert.setContentText("Piense un poco mas... :) miltonjesusvc@ufps.edu.co");
       alert.showAndWait();
    }

    @FXML
    public void cambiarFormato() {
     

        if(chexboxHora112.isSelected()){
         this.hora.setFormato(this.hora.HH12);   
        }
        if(chexboxHora124.isSelected()){
            this.hora.setFormato(this.hora.HH24);   
        }
        if(chexboxHora212.isSelected()){
         this.hora1.setFormato(this.hora1.HH12) ;  
        }
        if(chexboxHora224.isSelected()){
         this.hora1.setFormato(this.hora1.HH24);   
        }
        this.txtFormato.setText("Hora 1: "+hora.toString() +" <----> "+"Hora 2: "+hora1.toString());
  
    }

    @FXML
    public void comparar() {
      
        if(this.hora.esIgual(this.hora1)){
            this.txtHorasComparadas.setText("Son iguales las dos horas");
        }else
        if(this.hora.esMayor(this.hora1)){
            this.txtHorasComparadas.setText("La hora 1 es mayor");
        }
    }

    @FXML
    public void guardarDatos() {
        this.hora.setHoras(Integer.parseInt(this.txtHora1.getText()));
        this.hora.setMinutos(Integer.parseInt(this.txtMinuto1.getText()));
        this.hora.setSegundos(Integer.parseInt(this.txtSegundo1.getText()));
        this.hora1.setHoras(Integer.parseInt(this.txtHora2.getText()));
        this.hora1.setMinutos(Integer.parseInt(this.txtMinuto2.getText()));
        
    }

    @FXML
    public void limpiar() {

        
        this.txtFormato.setText("0");
        this.txtHora1.setText("0");
        this.txtHora2.setText("0");
        this.txtHorasComparadas.setText("0");
        this.txtMinuto1.setText("0");
        this.txtMinuto2.setText("0");
        this.txtResta.setText("0");
        this.txtSegundo1.setText("0");
        this.txtSegundo2.setText("0");
        
    }
 
    @FXML
    public void restar() {
        guardarDatos();
        this.txtResta.setText(String.valueOf(this.hora.restar(this.hora1)));
      
    }
    }


