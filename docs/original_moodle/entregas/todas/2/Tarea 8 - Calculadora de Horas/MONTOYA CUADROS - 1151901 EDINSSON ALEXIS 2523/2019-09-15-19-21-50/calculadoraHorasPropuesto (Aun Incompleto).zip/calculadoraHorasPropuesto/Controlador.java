import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Controlador {

    @FXML
    private TextField txtComparar;

    @FXML
    private TextField txtRestar;

    @FXML
    private Button cmdActualizarDatos;

    @FXML
    private Button cmdSolucionar;

    @FXML
    private Button cmdCambiarFormato;

    @FXML
    private TextField txtHoras1;

    @FXML
    private TextField txtMinutos1;

    @FXML
    private TextField txtSegundos1;

    @FXML
    private TextField txtHoras2;

    @FXML
    private TextField txtMinutos2;

    @FXML
    private TextField txtSegundos2;
    
    @FXML
    private TextField txtFormato;
    
    @FXML
    private TextField txtAmPm;
    
    protected Hora horaControl;
    
    public Controlador(){
        horaControl = new Hora();
        txtFormato.setText(String.valueOf("HH12"));
    }

    @FXML
    public void actualizarDatos() {
        horaControl.setFormato(String.valueOf(txtFormato.getText()));
        horaControl.setHoras(Integer.parseInt(txtHoras1.getText()));
        horaControl.setMinutos(Integer.parseInt(txtMinutos1.getText()));
        horaControl.setSegundos(Integer.parseInt(txtSegundos1.getText()));
        horaControl.setAmpm(String.valueOf(txtAmPm.getText()));
    }

    @FXML
    public void cambiarFormato() {
        if(horaControl.getFormato()=="HH12"){
            txtFormato.setText(String.valueOf("HH24"));
        }else txtFormato.setText(String.valueOf("HH12"));
    }

    @FXML
    public void solucionar() {
        Hora hora = new Hora();
        hora.setFormato(String.valueOf(txtFormato.getText()));
        hora.setHoras(Integer.parseInt(txtHoras2.getText()));
        hora.setMinutos(Integer.parseInt(txtMinutos2.getText()));
        hora.setSegundos(Integer.parseInt(txtSegundos2.getText()));
        hora.setAmpm(String.valueOf(txtAmPm.getText()));
        
        if(horaControl.esHoraValida()){
            //Comparar
            if(horaControl.getFormato()!="HH24" || hora.getFormato()!="HH24"){
                horaControl = horaControl.getHoraHH24();
                
            }
        }        
    }

}
